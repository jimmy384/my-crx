// ==UserScript==
// @name         ${name}
// @version      ${version}
// @description  ${description}
// @author       ${author}
// @namespace    ${namespace}
// @match        https://www.baidu.com/
// @run-at       document-end
// @connect      *
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// ==/UserScript==
