import $ from "jquery"
import {JSONPath} from "jsonpath-plus"

/**
 * 抽象爬虫
 * 拥有提取字段的能力
 */
class AbstractCrawler {
    constructor() {
        console.log("提取html的网页会用到jquery", $)
    }

    handleFields(current, fields) {
        const info = {}
        if (fields) {
            for (const field of fields) {
                const key = field.key
                if (field.type === "simple" || field.type === "arraySimple") {
                    const extractValueFn = this.getExtractValueFn(field)
                    const value = extractValueFn.apply(this, [current, field])
                    info[key] = value
                } else if (field.type === "arrayObject") {
                    const extractValueFn = this.getExtractValueFn(field)
                    const elements = this.jqueryListToArray(extractValueFn.apply(this, [current, field]))
                    const value = elements.map(element => this.handleFields(element, field.fields))
                    info[key] = value
                } else {
                    console.warn(`不支持的类型:${field.type}`)
                }
            }
        }
        return info
    }

    getExtractValueFn(field) {
        if (field.jsonPath) {
            return this.extractValueJsonPath
        } else if (field.selector) {
            return this.extractValueSelector
        } else {
            throw new Error(`field缺少配置jsonPath或者selector, key:${field.key}`)
        }
    }

    extractValueJsonPath(current, field) {
        const wrap = false
        return JSONPath.JSONPath({ path: field.jsonPath, json: current, wrap: wrap })
    }

    extractValueSelector(current, field) {
        return this.doEval(field.selector, { current: current })
    }

    doEval(script, context) {
        const argNames = Object.keys(context)
        const argValues = Object.values(context)
        const func = new Function(argNames, "return " + script)
        try {
            return func.apply(null, argValues)
        } catch (e) {
            console.error(`执行出错, 脚本:${script}`)
            throw e
        }
    }
}

export default AbstractCrawler