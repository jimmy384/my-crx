
import AbstractCrawler from "./AbstractCrawler"
import TempermonkeyHttpClient from "./http/TempermonkeyHttpClient"
import ChromeExtensionHttpClient from "./http/ChromeExtensionHttpClient"
import EnvironmentHelper from "./common/EnvironmentHelper"

/**
 * 可以处理以下类型的页面
 * 1.列表-详情页面
 * 2.单个详情页面
 */
class ListDetailPageCrawler extends AbstractCrawler {
    /**
     * 请求页面、结果字段提取的配置
     */
    flowDefinition
    /**
     * 发送请求函数，接收一个config对象(axios格式)，返回一个Promise
     */
    abstractHttpClient

    constructor(flowDefinition) {
        super()
        if (flowDefinition.listPage) {
            flowDefinition.listPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.listPage)
        }
        if (flowDefinition.detailPage) {
            flowDefinition.detailPage = Object.assign({}, flowDefinition.commonConfig, flowDefinition.detailPage)
        }
        this.flowDefinition = flowDefinition
        EnvironmentHelper.detectEnvironment({
            tampermonkey: () => {
                this.abstractHttpClient = new TempermonkeyHttpClient()
            },
            chromeExtension: () => {
                this.abstractHttpClient = new ChromeExtensionHttpClient()
            },
            other: () => {
                throw new Error("未知的运行环境")
            }
        })
    }

    async callFlow(config) {
        config = !config ? { pageNum: 1 } : config
        config.pageNum = !config.pageNum ? 1 : config.pageNum
        const { pageNum } = config
        const flowInst = JSON.parse(JSON.stringify(this.flowDefinition))
        const { listPage, detailPage } = flowInst

        // 存储某一页列表页面和这一页所有详情的信息
        const context = {}

        // 请求列表页面
        if (listPage) {
            if (listPage.url) {
                listPage.url = this.doEval("`" + this.flowDefinition.listPage.url + "`", { pageNum })
            }
            if (listPage.curl) {
                listPage.curl = this.doEval("`" + this.flowDefinition.listPage.curl + "`", { pageNum })
            }

            console.log("请求列表")
            const listPageData = await this.sendRequest(listPage)

            // 提取列表页面信息
            const listPageInfo = this.handleFields(listPageData, listPage.fields)
            context.listPage = listPageInfo
        }

        // 循环列表页面中的每一个详情页
        if (detailPage) {
            const evalCtx = { context }
            const isListDetailPage = detailPage.collection != null // 没有配置collection，则认为是单个详情页
            let list = isListDetailPage ? this.doEval(detailPage.collection, evalCtx) : [evalCtx]
            list = this.jqueryListToArray(list)
            const itemKey = detailPage.item || "item"
            const detailPageInfoList = []
            const resultList = []
            for (const item of list) {
                // 获取详情页地址
                evalCtx[itemKey] = item
                if (this.flowDefinition.detailPage.url) {
                    detailPage.url = this.doEval("`" + this.flowDefinition.detailPage.url + "`", evalCtx)
                }
                if (this.flowDefinition.detailPage.curl) {
                    detailPage.curl = this.doEval("`" + this.flowDefinition.detailPage.curl + "`", evalCtx)
                }
                // 请求详情页面
                console.log(`请求详情`)
                resultList.push(
                    this.sendRequest(detailPage).then(detailPageData => {
                        const detailPageInfo = this.handleFields(detailPageData, detailPage.fields)
                        detailPageInfoList.push(detailPageInfo)
                        return detailPageInfo
                    })
                )
                break
            }
            Promise.all(resultList).then(list => {
                console.log(list)
                context.detailPage = detailPageInfoList
                console.log("全部完成后的context", context)
            })
        }
        console.log(context)

        // 抓取下一页
        if (listPage) {
            const hasNextPage = context.listPage.totalPage && pageNum < context.listPage.totalPage || context.listPage.hasNextPage
            if (hasNextPage && (config.maxPageNum && pageNum < config.maxPageNum)) {
                config.pageNum++
                this.callFlow(config)
            }
        }
    }

    async sendRequest(config) {
        const requestInfo = await this.parseCurl(config.curl)
        if (requestInfo) {
            if (requestInfo.params) {
                config.url = requestInfo.url + "?" + new URLSearchParams(requestInfo.params).toString()
            } else {
                config.url = requestInfo.url
            }
            config.method = requestInfo.method
            config.headers = requestInfo.headers || {}
            config.data = requestInfo.body
        }
        return this.abstractHttpClient.sendRequest(config)
    }

    async parseCurl(curl) {
        return null
    }

    jqueryListToArray(list) {
        return list.jquery ? list.toArray() : list
    }
}

export default ListDetailPageCrawler