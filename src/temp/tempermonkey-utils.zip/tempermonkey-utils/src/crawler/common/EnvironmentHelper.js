function isTampermonkey() {
    return typeof GM_info !== 'undefined' || typeof GM_xmlhttpRequest !== 'undefined';
}

function isChromeExtension() {
    return typeof chrome !== 'undefined' && typeof chrome.runtime !== 'undefined' && typeof chrome.runtime.id !== 'undefined';
}

function detectEnvironment(config) {
    if (isTampermonkey()) {
        config.tampermonkey()
    } else if (isChromeExtension()) {
        config.chromeExtension()
    } else {
        config.other()
    }
}

export default {
    isTampermonkey,
    isChromeExtension,
    detectEnvironment
}