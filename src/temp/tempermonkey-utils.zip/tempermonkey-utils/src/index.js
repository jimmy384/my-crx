import ListDetailPageCrawler from "./crawler/ListDetailPageCrawler"

const flowDefinition = {
    listPage: {
        url: "https://www.wn04.cc/albums-index-page-${pageNum}-cate-10.html",
        fields: [
            {
                key: "manhuaList",
                type: "arrayObject",
                selector: "$(current).find('.gallary_item')",
                fields: [
                    {
                        key: "title",
                        type: "simple",
                        selector: "$(current).find('.title a').attr('title')"
                    },
                    {
                        key: "url",
                        type: "simple",
                        selector: "$(current).find('.title a').attr('href')"
                    }
                ]
            },
            {
                key: "hasNextPage",
                type: "simple",
                selector: "$(current).find('.next a').text()"
            }
        ]
    },
    detailPage: {
        collection: "context.listPage.manhuaList",
        url: "https://www.wn04.cc${item.url}",
        fields: [
            {
                key: "title",
                type: "simple",
                selector: "$(current).find('.userwrap h2').text()"
            },
            {
                key: "pageNum",
                type: "simple",
                selector: "$(current).find('.asTBcell.uwconn').children('label:last').text()"
            }
        ]
    }
}

const crawler = new ListDetailPageCrawler(flowDefinition)
const devConfig = {
    pageNum: 1,
    maxPageNum: 2
}
crawler.callFlow(devConfig)
